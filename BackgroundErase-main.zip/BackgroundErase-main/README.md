# BackgroundErase
Erase Background from Image

Note:- 

Required CroppedViewController to run this code
& Core ML also missing in code snippet


This is a demo project to support an article about using CoreML for image segmentation.
