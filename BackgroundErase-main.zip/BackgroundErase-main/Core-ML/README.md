# super-eureka

Note:- 

Required CroppedViewController to run this code
& Core ML also misisng in code snippet


This is a demo project to support an article about using CoreML for image segmentation.

This project uses some of Matthijs Hollemans' excellent [CoreMLHelper](https://github.com/hollance/CoreMLHelpers) utility functions to manipulate the different data types that CoreML and Vision produce.
